let songs = [
  {
    name: "Shree Krishna Govind",
    artist: "	Jubin Nautiyal",
    img: "img1",
    audio: "music1"
  },
  {
    name: "Ram Aayenge",
    artist: "Vishal Mishra",
    img: "img2",
    audio: "music2"
  },
  {
    name: "In The End",
    artist: "Tommee Profitt",
    img: "img3",
    audio: "music3"
  },
  {
    name: "Levitating ",
    artist: "Dua Lipa",
    img: "img4",
    audio: "music4"
  }
]